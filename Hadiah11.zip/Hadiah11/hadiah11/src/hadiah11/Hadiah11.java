/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiah11;

/**
 *
 * @author RAMON
 */
import java.awt.*;
public class Hadiah11 extends Panel{

    /**
     * @param args the command line arguments
     */
    Hadiah11() {
        setBackground(Color.GRAY);
    }
    
    public void paint(Graphics g) {
        //rambut
        g.setColor(Color.pink);
        g.drawOval(150,7,220,300);
        g.fillOval(150,7,220,300);
        //kepala
        g.setColor(Color.red);
        g.drawOval(200,8,120,120);
        g.fillOval(200,8,120,120);
        //poni
        g.setColor(Color.pink);
        g.drawOval(200,7,120,40);
        g.fillOval(200,7,120,40);
        // mata
        g.setColor(Color.BLACK);
        g.drawOval(235,50,8,8);
        g.fillOval(235,50,8,8);
        g.setColor(Color.BLACK);
        g.drawOval(280,50,8,8);
        g.fillOval(280,50,8,8);
        //mulut
        g.setColor(Color.BLACK);
        g.drawArc(250,70,20,20,10,-170);
        //badan
        g.drawLine(100,170,400,170);
        g.drawLine(255,130,255,400);
        g.drawLine(255, 400, 100, 500);
        g.drawLine(255, 400, 400, 500);
          
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        Hadiah11 gp = new Hadiah11();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
